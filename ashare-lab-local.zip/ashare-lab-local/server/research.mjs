import {mkdir,readFile,writeFile,rename,readdir,rm,open,access} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash,randomUUID} from 'node:crypto';
import {spawn,execFile} from 'node:child_process';
import {Worker} from 'node:worker_threads';
import {defaults,validate} from '../dist/engine.mjs';
import {auditBundle,auditDisposition,isAuditAdmitted} from '../dist/quality.mjs';
import {resampleData} from '../dist/data.mjs';
import {parseCollectionCodes,batchLimit} from '../dist/collection-batch.mjs';
import {requiredWarmupSessions} from '../dist/research-input.mjs';
import {validateParameterValue} from '../dist/parameter-schema.mjs';
import {validateTrainingInputs} from '../dist/training-input.mjs';
import {ensureTiming,accrue,startTiming,stopTiming,timingView,iso} from './research-timing.mjs';

const project=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
export const canonical=value=>JSON.stringify(value,(_key,v)=>v&&typeof v==='object'&&!Array.isArray(v)?Object.fromEntries(Object.keys(v).sort().map(k=>[k,v[k]])):v);
export const hash=bytes=>createHash('sha256').update(bytes).digest('hex');
const now=()=>new Date().toISOString(),date=s=>typeof s==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(s)&&Number.isFinite(Date.parse(s))&&new Date(s).toISOString().slice(0,10)===s;
const failure=(code,message,details)=>Object.assign(Error(message),{code,details});
// Reviewed predecessors retain collection query identities and price basis.
// Research jobs remain pinned to their strategy engine; collection-only jobs
// never execute that engine. All collection responses are still revalidated.
// Unknown pipelines still cannot reuse old work.
const compatiblePipelines=new Set(['feaf2b252fc38d999dd99d4d00d03b8c65586e46a75e723b340be297cbe21fa1','9b4f4b276eb73097580a9f4ab61428f50c6ad49b79e47fe97f353a2658df838f','c5db467fb8196caa8a6b68a9af2b65f4b80a650aca3bd79da1c883685591990e','37fa697413f07b2a1701a50d85a55030148c7c5236e125f341be1a3a72a0c100','f16cb4ed61cff168dd1b1b79befa5b9b03d1a555c4c2470dae9792eb760deae9','d7b13b8d804033f7b269d961e14b6e81d993fb45d45c03a6e5610e5b751f1f82','cbfe084871bf787bdd04c3a66462968ba036ab9372758022b316883befd22230','5afc9f0da8aa1fcf7ac888b19d8435c35a38c48b1277b1355bc97359a14968fe','e1b827395f9f64119f1f8fd3cb88e5f41a7de64c7434e9547ee0549805ddb396','42a250326c788ca9a1b81e818537396179b2d6b2b3ad822dee6f44493bd333e9','5ba9106a87d7f621d730eb8366b486f172862bb0950bc1afc326410e1fa83967','29824a5da745fb0d388a82719a4c4ff0c3b0bb3de81b5dc25a61a44ba4d0e36c','4b3ee26892f85078e72336fa3c010116d812272e8f16b5a4189fa6702062cb13']);
async function atomic(target,value){await mkdir(path.dirname(target),{recursive:true});const temp=target+'.tmp-'+randomUUID(),handle=await open(temp,'wx');try{await handle.writeFile(typeof value==='string'?value:canonical(value));await handle.sync();}finally{await handle.close();}await rename(temp,target);}
export function yearStart(to){const d=new Date(to+'T00:00:00Z');d.setUTCDate(d.getUTCDate()+1);d.setUTCFullYear(d.getUTCFullYear()-1);return d.toISOString().slice(0,10);}
export function normalizeRequest(input){
  if(!input||typeof input!=='object'||Array.isArray(input))throw failure('REQUEST','任务请求无效');
  const symbol=String(input.symbol??'600519'),board=symbol.startsWith('688')?'star':/^30[01]/.test(symbol)?'chinext':'main';
  if(!/^(6\d{5}|[03]\d{5})$/.test(symbol))throw failure('REQUEST','此验收仅支持BaoStock沪深证券代码');
  if(input.board&&input.board!==board)throw failure('REQUEST','显式板块与证券代码不符');
  if(!date(input.to))throw failure('REQUEST','请选择有效的研究结束日期');
  const today=new Date(Date.now()+8*3600000).toISOString().slice(0,10);
  if(input.to>=today)throw failure('REQUEST','研究结束日期必须早于北京时间今天，避免采集未完成交易日');
  const rangeMode=input.rangeMode??(input.from===undefined?'year':'custom');
  if(!['year','custom'].includes(rangeMode))throw failure('REQUEST','研究区间模式须为year或custom');
  const from=rangeMode==='year'?yearStart(input.to):input.from;
  if(!date(from))throw failure('REQUEST','请选择有效的研究开始日期');
  if(from>=input.to)throw failure('REQUEST','研究开始日期必须早于结束日期');
  if(rangeMode==='year'&&input.from!==undefined&&input.from!==from)throw failure('REQUEST','一年模式的开始日期由结束日期自动计算；自定义日期请使用custom模式');
  const cfg=Object.fromEntries(Object.keys(defaults).map(k=>[k,input.config?.[k]??defaults[k]]));
  Object.assign(cfg,{from,to:input.to,board,dataMode:'formal',rulesMode:'historical'});
  const purpose=input.purpose??'research';if(!['collect','research'].includes(purpose))throw failure('REQUEST','任务用途须为collect或research');
  if(!(purpose==='collect'?['5m','15m','1d']:['5m','15m']).includes(cfg.timeframe))throw failure('REQUEST','仅采集可指定5分钟、15分钟或日线回测；沪深300正式验收需5或15分钟。原始采集均为5分钟');
  if(purpose==='collect'){
    // Only these periods affect the amount of raw history requested. A
    // collection job never runs a strategy or uses profit/risk thresholds.
    for(const key of ['dailySlow','breakout','exitPeriod','atrPeriod','confirmationDays','slow','macdSlow','macdSignal','rsiPeriod','bbPeriod']){
      try{validateParameterValue(key,cfg[key]);}catch(e){throw failure('REQUEST','采集预热参数无效：'+e.message,{parameter:key});}
    }
  }else{
    try{validateTrainingInputs(cfg);validate(cfg);}catch(e){throw failure('REQUEST',e.message,e.parameter?{parameter:e.parameter}:undefined);}
  }
  const minimumWarmup=requiredWarmupSessions(cfg),warmupSessions=input.warmupSessions??minimumWarmup;
  if(!Number.isInteger(warmupSessions)||warmupSessions<minimumWarmup||warmupSessions>1000)throw failure('REQUEST',`预热交易日须为 ${minimumWarmup} 至 1000 的整数；不能低于当前参数的预热要求`);
  const budget=input.budget??10000;if(!Number.isInteger(budget)||budget<1||budget>40000)throw failure('REQUEST','日预算须为1至40000，默认10000');
  return {schemaVersion:1,symbol,board,purpose,rangeMode,from,to:input.to,warmupSessions,budget,provider:'baostock',config:cfg};
}
export function acceptanceAudit(bundle,request){
  const collectOnly=request.purpose==='collect',quality=auditBundle(bundle),issues=quality.issues.filter(i=>!collectOnly||!i.code.startsWith('UNIVERSE_')),add=(code,message)=>issues.push({code,message,count:1,samples:[]});
  const m=bundle.metadata??{},rows=bundle.bars??[];
  if(m.symbol!==request.symbol||m.board!==request.board)add('IDENTITY','数据包证券或板块不符');
  if(m.timeframe!=='5m')add('NATIVE_5M','验收必须使用原生5分钟，禁止拆分日线或15分钟');
  if(m.requested?.to!==request.to||m.requested?.from>=request.from)add('RESEARCH_RANGE','数据包须完整覆盖研究区间和独立预热区间');
  if(m.research&&(m.research.from!==request.from||m.research.to!==request.to||m.research.warmupSessions!==request.warmupSessions))add('RESEARCH_RANGE','采集回执的研究区间或预热要求与固定请求不一致');
  if(!m.synthetic&&(m.source!=='baostock'||!Object.keys(m.provenance?.queries??{}).length))add('PROVENANCE','缺少BaoStock原始查询检查点证明');
  if(!m.synthetic&&['bars','daily','calendar','universe','actions','factors'].some(k=>!m.parquetArchive?.tables?.[k]))add('PARQUET_ARCHIVE','缺少完整本地Parquet归档回执');
  const warm=(bundle.calendar??[]).filter(d=>d>=m.requested?.from&&d<request.from&&d>=m.listedDate);
  if(warm.length<request.warmupSessions)add('WARMUP','完整预热交易日不足：需要'+request.warmupSessions+'日');
  const code=(request.symbol.startsWith('6')?'sh.':'sz.')+request.symbol;
  if(!collectOnly&&!(bundle.universe??[]).some(u=>u.date>=request.from&&u.date<=request.to&&u.codes?.includes(code)))add('HISTORICAL_MEMBER','研究区间内未证明曾为沪深300成分股');
  if(!rows.some(r=>r.date.slice(0,10)>=request.from&&r.date.slice(0,10)<=request.to))add('RESEARCH_EMPTY','研究区间无分钟数据');
  const disposition=auditDisposition(issues),label=disposition.status==='blocked'?(collectOnly?'行情已保存，存在阻断问题':'不可正式回测'):disposition.status==='warning'?'可回测 · 存在量价警告（未修复）':collectOnly?'行情完整性校验通过，未核验指数成员':quality.label;
  return {...quality,...disposition,label,...(collectOnly?{scope:'market-data-only'}:{}),issues,warmupSessions:warm.length,requiredWarmup:request.warmupSessions,research:{from:request.from,to:request.to},synthetic:m.synthetic===true};
}
// Separate accounting checks use raw closing prices, quantities and fees from
// saved outputs. This is deliberately independent of the engine's NAV formula.
export function auditAccounting(result,bundle){
  const prices=new Map(resampleData(bundle.bars,result.config.timeframe).map(r=>[r.date,r.close]));
  const daily=new Map(bundle.daily.map(d=>[d.date,d])),exDates=new Set(bundle.actions.map(a=>a.exDate));
  const movements=result.trades.map(t=>({at:t.confirmationTime??t.executionTime,cash:t.side==='买入'?-t.amount-t.fee:t.amount-t.fee,quantity:t.side==='买入'?t.quantity:-t.quantity,locked:0,receivable:0}));
  for(const e of result.corporateEvents){const p={at:e.date+' 09:00',cash:0,quantity:0,locked:0,receivable:0};if(e.event==='股息到账'){p.cash=e.amount;p.receivable=-e.amount;}else if(e.event==='送转股上市'){p.quantity=e.quantity;p.locked=-e.quantity;}else if(e.event==='除权权益入账'){p.receivable=e.cashReceivable;p.locked=e.lockedShares;}else continue;movements.push(p);}
  movements.sort((a,b)=>a.at.localeCompare(b.at));let cursor=0,cash=result.config.capital,quantity=0,locked=0,receivable=0;
  let checked=0;for(const p of result.curve){const day=p.date.slice(0,10),d=daily.get(day),price=prices.get(p.date)??(p.valuationOnly?(exDates.has(day)?d?.prev_close:d?.close):undefined);
    while(cursor<movements.length&&movements[cursor].at<=(p.date.length===10?p.date+' 15:00':p.date)){const flow=movements[cursor++];cash+=flow.cash;quantity+=flow.quantity;locked+=flow.locked;receivable+=flow.receivable;}
    if(Math.abs(p.cash-cash)>.011||p.quantity!==quantity||p.lockedQuantity!==locked||Math.abs(p.receivable-receivable)>.011)throw failure('ACCOUNTING','成交现金流、股份或权益流水核对失败：'+p.date);
    const expected=p.cash+(p.quantity+p.lockedQuantity)*price+p.receivable;
    if(!Number.isFinite(expected)||Math.abs(p.equity-expected)>0.011||Math.abs(p.nav-p.equity/result.config.capital)>1e-10||p.cash<-.011||p.quantity<0)throw failure('ACCOUNTING','现金、持仓或净值核对失败：'+p.date);
    checked++;
  }
  const fees=result.trades.reduce((s,t)=>s+t.fee,0);
  if(Math.abs(fees-result.metrics.fees)>.011||Math.abs(result.metrics.equity-result.curve.at(-1).equity)>.011)throw failure('ACCOUNTING','成交费用或期末资产核对失败');
  for(const t of result.trades){if(t.signalTime>t.executionTime||t.dailySignalTime&&t.dailySignalTime>t.executionTime)throw failure('LOOKAHEAD','发现执行早于信号可得时间');if(Math.abs(t.amount-t.quantity*t.price)>.011||t.side==='卖出'&&t.sellableBefore<t.quantity)throw failure('ACCOUNTING','成交金额或T+1可卖库存核对失败');}
  for(const o of result.orderAttempts??[])if(o.signalTime>o.submittedAt||o.dailySignalTime&&o.dailySignalTime>o.submittedAt||o.submittedAt>o.evidenceAvailableAt||o.evidenceAvailableAt>o.resolvedAt)throw failure('LOOKAHEAD','订单提交或成交确认时序不符');
  for(const t of result.trades)if(t.confirmationTime&&t.executionTime>t.confirmationTime)throw failure('LOOKAHEAD','成交确认早于估算执行时间');
  if((result.orderAttempts??[]).some(o=>o.status==='unfilled'&&result.trades.some(t=>t.orderId===o.id)))throw failure('ACCOUNTING','未成交订单错误进入成交账簿');
  return {status:'passed',valuationPoints:checked,fees,checks:['order and corporate cash/share movements','cash + tradable/locked stock value + dividend receivable','order fee sum','final equity','signal availability','sellable quantity']};
}
async function engineHash(){const files=['engine.mjs','quality.mjs','data.mjs','rules.mjs','corporate.mjs','fees.mjs','inventory.mjs','corporate-correction.mjs','corporate-evidence.json'];const parts=[];for(const f of files)parts.push([f,hash(await readFile(path.join(project,'dist',f)))]);parts.push(['runner',hash(await readFile(path.join(project,'server/research-runner.mjs')))]);return hash(canonical(parts));}
async function pipelineHash(){const files=['server/research.mjs','server/research-timing.mjs','collector/research_collect.py','collector/query_cache.py','dist/research-input.mjs','dist/parameter-schema.mjs','dist/training-input.mjs','collector/sources.py','collector/sync.py','collector/locking.py','collector/baostock_guard.py','collector/public_ip.py','collector/parquet_store.py','collector/corporate_correction.py','dist/corporate-evidence.json'];const parts=[];for(const f of files)parts.push([f,hash(await readFile(path.join(project,f)))]);return hash(canonical(parts));}
const jsonResponse=(v,status=200)=>new Response(JSON.stringify(v),{status,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'}});
// Node decodes collector output as UTF-8; Windows pipe encodings must match.
const pythonEnv=()=>({...process.env,PYTHONIOENCODING:'utf-8'});

export class ResearchManager {
  constructor({root,bucket,collector,runner,clock=Date.now,heartbeatMs=5000}={}){this.root=path.resolve(root);this.bucket=bucket;this.collector=collector;this.runner=runner;this.clock=clock;this.heartbeatMs=heartbeatMs;this.jobs=new Map();this.batches=new Map();this.batchWrites=Promise.resolve();this.active=null;this.stopping=false;this.saves=Promise.resolve();}
  location(id,name){if(!/^[a-f0-9]{24}$/.test(id))throw failure('NOT_FOUND','任务不存在');return path.join(this.root,'jobs',id,name);}
  async init(){
    await mkdir(this.root,{recursive:true});this.lock=path.join(this.root,'.controller-lock');this.owner=randomUUID();
    try{await mkdir(this.lock);}catch(e){if(e.code!=='EEXIST')throw e;let owner;try{owner=JSON.parse(await readFile(path.join(this.lock,'owner.json'),'utf8'));}catch{throw Error('任务控制锁未完成初始化；检查是否有另一服务正在启动');}
      let alive=true;try{process.kill(owner.pid,0);}catch(e){if(e.code==='ESRCH')alive=false;}
      if(alive)throw Error('该数据目录已有本地任务服务，禁止两个调度器并发');await rm(this.lock,{recursive:true});await mkdir(this.lock);
    }
    await atomic(path.join(this.lock,'owner.json'),{pid:process.pid,owner:this.owner});this.fingerprint=await engineHash();this.pipelineFingerprint=await pipelineHash();
    await mkdir(path.join(this.root,'batches'),{recursive:true});
    for(const file of await readdir(path.join(this.root,'batches'))){if(!/^[a-f0-9]{24}\.json$/.test(file))continue;const id=file.slice(0,-5);
      try{const b=JSON.parse(await readFile(this.batchLocation(id),'utf8'));if(b.id!==id||!Array.isArray(b.requests)||b.requests.length<1||b.requests.length>batchLimit||b.jobIds?.length!==b.requests.length||hash(canonical(b.requests))!==b.requestHash||b.requests.some((r,i)=>b.jobIds[i]!==this.batchJobId(id,i)))throw Error('批次请求或任务编号校验失败');this.batches.set(id,b);}
      catch(e){this.batches.set(id,{id,creationState:'blocked',createdAt:now(),error:{code:'BATCH_INTEGRITY',message:e.message},requests:[],jobIds:[]});}
    }
    await mkdir(path.join(this.root,'jobs'),{recursive:true});
    for(const id of await readdir(path.join(this.root,'jobs'))){if(!/^[a-f0-9]{24}$/.test(id))continue;
      try{const state=JSON.parse(await readFile(this.location(id,'state.json'),'utf8'));const raw=await readFile(this.location(id,'request.json'),'utf8');
        if(hash(raw)!==state.requestHash)throw Error('任务请求哈希不符');state.request=JSON.parse(raw);this.jobs.set(id,state);
        ensureTiming(state);
        if(state.status==='running'){stopTiming(state,this.clock(),'interrupted',{recovered:true});state.status='queued';state.recoveryCount=(state.recoveryCount??0)+1;await this.save(state,'服务中断后自动恢复；累计时间截至最后落盘心跳，停机期间不计时；复用已完成分段');}
      }catch(e){const staged=[...this.batches.values()].some(b=>b.creationState==='staging'&&b.jobIds.includes(id));let stateExists=true;try{await access(this.location(id,'state.json'));}catch(x){if(x.code==='ENOENT')stateExists=false;}
        if(staged&&!stateExists)continue;const state={id,status:'failed',stage:'recovery',createdAt:now(),updatedAt:now(),events:[],error:{code:'JOB_INTEGRITY',message:e.message}};this.jobs.set(id,state);}
    }
    for(const b of this.batches.values())if(b.creationState==='staging'){try{await this.stageBatch(b);}catch(e){b.creationState='blocked';b.error={code:e.code??'BATCH_RECOVERY',message:e.message};await atomic(this.batchLocation(b.id),b);}}
    this.pump();return this;
  }
  async save(job,message){const at=this.clock();accrue(job,at);job.updatedAt=iso(at);let event;
    if(message){event={at:job.updatedAt,stage:job.stage,message,activeMs:job.timing.activeMs,stageMs:job.timing.stages[job.stage]??0,run:job.timing.runs.length};job.events??=[];job.events.push(event);job.events=job.events.slice(-80);}
    const copy=JSON.parse(JSON.stringify(job));delete copy.request;delete copy.controller;this.saves=this.saves.catch(()=>{}).then(async()=>{await atomic(this.location(job.id,'state.json'),copy);if(event)await writeFile(this.location(job.id,'events.jsonl'),canonical(event)+'\n',{flag:'a'});});await this.saves;
  }
  view(job){const {controller,...value}=job;return {...value,timing:timingView(job,this.clock()),events:job.events??[]};}
  async create(input,{replay,normalized,id=randomUUID().replaceAll('-','').slice(0,24),batchId,versions,deferPump=false}={}){
    const request=normalized??(replay?replay.request:normalizeRequest(input)),bytes=canonical(request);
    const job={id,request,requestHash:hash(bytes),engineHash:versions?.engineHash??replay?.engineHash??this.fingerprint,pipelineHash:versions?.pipelineHash??replay?.pipelineHash??this.pipelineFingerprint,configHash:hash(canonical(request.config)),status:'queued',stage:'queued',createdAt:iso(this.clock()),updatedAt:iso(this.clock()),events:[],recoveryCount:0,timing:{version:1,activeMs:0,stages:{},runs:[],accountedAt:null}};
    if(replay){job.snapshotId=replay.snapshotId;job.expectedResultHash=replay.resultHash;job.replayOf=replay.id;}
    if(batchId)job.batchId=batchId;
    await atomic(this.location(id,'request.json'),bytes);await this.save(job,'任务已保存，等待串行执行');this.jobs.set(id,job);if(!deferPump)this.pump();return this.view(job);
  }
  batchLocation(id){if(!/^[a-f0-9]{24}$/.test(id))throw failure('NOT_FOUND','批次不存在');return path.join(this.root,'batches',id+'.json');}
  batchJobId(id,i){return hash(id+':'+i).slice(0,24);}
  batchView(b){const jobs=b.jobIds.map(id=>this.jobs.get(id)),counts=Object.fromEntries(['queued','running','paused','blocked','failed','completed'].map(s=>[s,jobs.filter(j=>j?.status===s).length]));return {id:b.id,createdAt:b.createdAt,creationState:b.creationState,paused:!!b.paused,duplicates:b.duplicates,total:b.requests.length,symbols:b.requests.map(r=>r.symbol),from:b.requests[0]?.from,to:b.requests[0]?.to,purpose:b.requests[0]?.purpose,jobIds:b.jobIds,counts,missing:jobs.filter(j=>!j).length,incomplete:jobs.filter(j=>j?.status==='completed'&&j.quality?.status==='blocked').length,activeMs:jobs.reduce((s,j)=>s+(j?timingView(j,this.clock()).activeMs:0),0),error:b.error??null};}
  async stageBatch(b){
    for(let i=0;i<b.requests.length;i++){const id=b.jobIds[i],request=b.requests[i],digest=hash(canonical(request)),existing=this.jobs.get(id);
      if(existing){if(existing.requestHash!==digest||existing.batchId!==b.id)throw failure('BATCH_INTEGRITY','批次已有任务不匹配，保留原始证据');continue;}
      let prior;try{prior=await readFile(this.location(id,'request.json'),'utf8');}catch(e){if(e.code!=='ENOENT')throw e;}
      if(prior!==undefined&&hash(prior)!==digest)throw failure('BATCH_INTEGRITY','未完成写入的任务请求哈希不匹配');
      await this.create(null,{normalized:request,id,batchId:b.id,versions:b.versions,deferPump:true});
    }
    b.creationState='ready';delete b.error;await atomic(this.batchLocation(b.id),b);this.pump();return this.batchView(b);
  }
  async createBatch(input){
    let parsed;try{parsed=parseCollectionCodes(input?.symbols);}catch(e){throw failure('REQUEST',e.message);}
    const requests=parsed.symbols.map(symbol=>normalizeRequest({...input,symbol}));
    const key=input.requestId??randomUUID();if(typeof key!=='string'||!/^[A-Za-z0-9_-]{8,100}$/.test(key))throw failure('REQUEST','批量提交编号无效');
    const id=hash('batch:'+key).slice(0,24),requestHash=hash(canonical(requests));
    const operation=this.batchWrites.catch(()=>{}).then(async()=>{
      const existing=this.batches.get(id);if(existing){if(existing.requestHash!==requestHash)throw failure('REQUEST','同一提交编号不能用于不同代码或参数');if(existing.creationState==='staging')await this.stageBatch(existing);return {...this.batchView(existing),reused:true};}
      const b={schemaVersion:1,id,createdAt:iso(this.clock()),creationState:'staging',paused:false,versions:{engineHash:this.fingerprint,pipelineHash:this.pipelineFingerprint},requestHash,requests,duplicates:parsed.duplicates,jobIds:requests.map((_,i)=>this.batchJobId(id,i))};
      await atomic(this.batchLocation(id),b);this.batches.set(id,b);await this.stageBatch(b);return this.batchView(b);
    });this.batchWrites=operation;return operation;
  }
  async holdBatch(id,message){const b=this.batches.get(id);if(!b)return;b.paused=true;b.error={code:'SOURCE_LIMIT',message:'数据源限流或黑名单：本批已暂停，保留断点；处理限制后手动恢复。'+message};await atomic(this.batchLocation(id),b);for(const jobId of b.jobIds){const job=this.jobs.get(jobId);if(job?.status==='queued'){job.status='paused';await this.save(job,'同批触发数据源流量限制，停止排队请求，保留断点等待手动恢复');}}}
  async pauseBatch(id){const b=this.batches.get(id);if(!b)throw failure('NOT_FOUND','批次不存在');b.paused=true;await atomic(this.batchLocation(id),b);for(const jobId of b.jobIds){const job=this.jobs.get(jobId);if(['queued','running'].includes(job?.status))await this.pause(jobId);}return this.batchView(b);}
  async resumeBatch(id){const b=this.batches.get(id);if(!b)throw failure('NOT_FOUND','批次不存在');if(b.creationState!=='ready')throw failure('STATE','批次创建未完成或完整性受阻，请先处理错误');b.paused=false;delete b.error;await atomic(this.batchLocation(id),b);const errors=[];for(const jobId of b.jobIds)if(['paused','blocked','failed'].includes(this.jobs.get(jobId)?.status)){try{await this.resume(jobId);}catch(e){errors.push({id:jobId,message:e.message});}}this.pump();return {...this.batchView(b),resumeErrors:errors};}
  pump(){if(this.active||this.stopping)return;const job=[...this.jobs.values()].filter(j=>j.status==='queued'&&(!j.batchId||this.batches.get(j.batchId)?.creationState==='ready'&&!this.batches.get(j.batchId).paused)).sort((a,b)=>a.createdAt.localeCompare(b.createdAt))[0];if(!job)return;
    this.active=job;job.status='running';job.controller=new AbortController();startTiming(job,this.clock());
    const heartbeat=setInterval(()=>{if(job.status==='running')this.save(job).catch(()=>{});},this.heartbeatMs);heartbeat.unref();
    this.running=this.execute(job).catch(async e=>{const paused=job.controller.signal.aborted||e.code==='PAUSED';const status=paused?'paused':e.code==='ACCOUNTING'||e.code==='REPRODUCIBILITY'||e.code==='SNAPSHOT_HASH'?'failed':'blocked';stopTiming(job,this.clock(),status);job.status=status;job.error={code:e.code??'TASK_ERROR',message:e.message,...(e.details?{details:e.details}:{})};delete job.controller;await this.save(job,e.message);if(!paused)await this.saveReport(job,{schemaVersion:1,acceptance:'blocked',input:{requestHash:job.requestHash,configHash:job.configHash,engineHash:job.engineHash,pipelineHash:job.pipelineHash,snapshotId:job.snapshotId??null},request:job.request,error:job.error,quality:job.quality??null});if(!paused&&job.batchId&&/黑名单|10001011|日请求预算/.test(e.message))await this.holdBatch(job.batchId,e.message);}).finally(()=>{clearInterval(heartbeat);delete job.controller;this.active=null;this.pump();});
  }
  check(job){if(job.controller?.signal.aborted||this.stopping)throw failure('PAUSED','任务已暂停，断点保留');}
  async stage(job,stage,message){this.check(job);accrue(job,this.clock());job.stage=stage;await this.save(job,message);}
  async progress(job,p){
    if(p.collectionPlan)job.collectionPlan=p.collectionPlan;
    if(p.sourceUsage)job.sourceUsage=p.sourceUsage;
    job.progress=p;let message;
    if(p.collectionRange)job.collectionRange=p.collectionRange;
    if(p.stage==='blocked')job.collectorError=p;
    if(p.query){
      const query=p.query.join(' / ');
      if(p.phase==='query-start')message=(p.cached?'校验缓存：':'开始查询：')+query;
      else if(p.queryElapsedMs!==undefined){
        const stats=job.queryTiming??={};const s=stats[p.query[0]]??={completed:0,failed:0,cached:0,elapsedMs:0,rateWaitMs:0,requests:0};
        s[p.phase==='query-error'?'failed':'completed']++;if(p.cached)s.cached++;s.elapsedMs+=p.queryElapsedMs;s.rateWaitMs+=p.rateWaitMs??0;s.requests+=p.requests??0;
        message=`${p.phase==='query-error'?'查询中断':p.cacheOrigin==='shared'?'跨任务复用':p.cached?'复用断点':'查询完成'}：${query} · ${p.rows??0} 行 · 耗时 ${(p.queryElapsedMs/1000).toFixed(3)}秒 · 限流等待 ${((p.rateWaitMs??0)/1000).toFixed(3)}秒 · SDK请求 ${p.requests??0} 次`;
      }
    }else if(p.message)message=p.message;
    await this.save(job,message);
  }
  async execute(job){
    await this.stage(job,'preflight','检查固定输入和引擎版本');
    if(hash(await readFile(this.location(job.id,'request.json')))!==job.requestHash)throw failure('REQUEST_HASH','任务参数文件发生变化');
    if(job.request.purpose!=='collect'&&job.engineHash!==await engineHash())throw failure('ENGINE_CHANGED','引擎代码已改变。旧任务不能用新引擎静默恢复，请创建新任务');
    // An immutable snapshot needs no collection checkpoints. Keep its original
    // provenance while checking request/snapshot hashes and, for research, engine.
    const currentPipeline=await pipelineHash();
    if(!job.snapshotId&&job.pipelineHash!==currentPipeline){
      if(compatiblePipelines.has(job.pipelineHash)){
        job.pipelineMigrations??=[];job.pipelineMigrations.push({from:job.pipelineHash,to:currentPipeline,at:iso(this.clock()),reason:'已审查升级：查询身份和行情口径兼容；采集任务不运行策略引擎，断点仍按当前规则重新校验'});job.pipelineHash=currentPipeline;
        await this.save(job,'兼容恢复旧任务，保留原参数及累计时间；交易日历先校验完整覆盖，不完整日历隔离后重查；升级前未计时时段无法补测');
      }else throw failure('PIPELINE_CHANGED','采集或验收代码已改变，不能与旧断点混用，请创建新任务');
    }
    const cfg=job.request.config,collection=this.location(job.id,'collection');let bundle,bytes;
    if(job.snapshotId){const object=await this.bucket.get('snapshots/'+job.snapshotId+'.json');if(!object)throw failure('SNAPSHOT_MISSING','固定行情快照不存在');bytes=Buffer.from(object.body);if(hash(bytes)!==job.snapshotId)throw failure('SNAPSHOT_HASH','固定行情快照哈希不一致');bundle=JSON.parse(bytes);}
    else {
      await this.stage(job,'collect',job.request.purpose==='collect'?'采集指定证券原生5分钟、日线、历史状态和公司行动；不查询沪深300成员':'采集原生5分钟及日线、历史状态、成分和公司行动');await mkdir(collection,{recursive:true});await rm(path.join(collection,'cancel'),{force:true});
      if(this.collector){bundle=await this.collector(job.request,collection,job.controller.signal,p=>this.progress(job,p));bytes=Buffer.from(canonical(bundle));}
      else {await this.collectPython(job,collection);bytes=await readFile(path.join(collection,'bundle.json'));const receipt=JSON.parse(await readFile(path.join(collection,'receipt.json'),'utf8'));if(hash(bytes)!==receipt.sha256)throw failure('CACHE_HASH','采集结果与检查点回执不符');bundle=JSON.parse(bytes);bytes=Buffer.from(canonical(bundle));}
    }
    await this.stage(job,'validate','逐日核验48根原生5分钟、日线量价、历史ST、预热及除权因子');job.quality=acceptanceAudit(bundle,job.request);await this.save(job);
    if(!isAuditAdmitted(job.quality)&&job.request.purpose!=='collect')throw failure('DATA_ADMISSION','资料未通过正式准入；保留缺口报告',job.quality.blockingIssues);
    await this.stage(job,'ingest','保存不可变行情快照并读回核对SHA-256');const id=hash(bytes);
    const old=await this.bucket.get('snapshots/'+id+'.json');if(old&&hash(Buffer.from(old.body))!==id)throw failure('SNAPSHOT_HASH','仓库已有对象哈希不符');
    if(!old)await this.bucket.put('snapshots/'+id+'.json',bytes);
    const manifest={id,symbol:bundle.metadata.symbol,name:bundle.metadata.name??'',board:bundle.metadata.board,timeframe:'5m',source:bundle.metadata.source,syncedAt:job.createdAt,bytes:bytes.length,report:auditBundle(bundle,{scope:job.request.purpose==='collect'?'single-security':'hs300'})};
    if(!await this.bucket.get('manifests/'+id+'.json'))await this.bucket.put('manifests/'+id+'.json',canonical(manifest));
    if(hash(Buffer.from((await this.bucket.get('snapshots/'+id+'.json')).body))!==id)throw failure('SNAPSHOT_HASH','入库后读回核对失败');job.snapshotId=id;await this.save(job);
    const snapshot=this.location(job.id,'input.json');await atomic(snapshot,bytes.toString('utf8'));
    if(job.request.purpose==='collect'){
      // Collection preserves incomplete raw evidence too, but never runs the
      // engine or claims HS300 research admission. Formal audit stays strict.
      job.acceptance=bundle.metadata.synthetic?'synthetic-test-only':job.quality.status==='warning'?'market-data-with-warnings':job.quality.status==='passed'?'market-data-only':'market-data-incomplete';job.resultHash=id;
      await this.stage(job,'report','保存行情采集报告；未进行策略回测或指数成员资格校验');
      await this.saveReport(job,{schemaVersion:1,acceptance:job.acceptance,input:{requestHash:job.requestHash,pipelineHash:job.pipelineHash,snapshotId:id},request:job.request,quality:job.quality,collection:{bars:bundle.bars.length,daily:bundle.daily.length,membershipChecked:false,incremental:bundle.metadata.incrementalPlan??null},limitations:['此报告仅确认行情采集和完整性，不是沪深300正式回测准入或盈利证明','存在资料问题时保留原始行情和问题清单，不补造缺失数据']});
      stopTiming(job,this.clock(),'completed');job.status='completed';job.stage='completed';delete job.error;await this.save(job,job.quality.status==='warning'?'行情已入库，可带量价警告回测；数据未修复，未查询指数成员':job.quality.status==='passed'?'行情采集完成，已入库；未查询指数成员、未运行回测':'行情已入库，存在阻断问题，请查看报告');return;
    }
    const runConfig={...cfg,snapshotId:id};
    await this.stage(job,'backtest','后台运行回测；网页关闭后任务仍继续');const first=await this.runEngine(job,snapshot,runConfig);this.check(job);
    await this.stage(job,'verify','使用同一快照和参数独立重跑，并核对资产及费用');const second=await this.runEngine(job,snapshot,runConfig);const firstHash=hash(canonical(first)),secondHash=hash(canonical(second));
    if(firstHash!==secondHash||job.expectedResultHash&&firstHash!==job.expectedResultHash)throw failure('REPRODUCIBILITY','相同输入得到不同结果，验收失败');
    const accounting=auditAccounting(first,bundle);job.resultHash=firstHash;job.acceptance=bundle.metadata.synthetic?'synthetic-test-only':job.quality.status==='warning'?'passed-with-warnings':'passed';
    const report={schemaVersion:1,acceptance:job.acceptance,input:{requestHash:job.requestHash,configHash:job.configHash,engineHash:job.engineHash,pipelineHash:job.pipelineHash,snapshotId:id,runtime:{node:process.versions.node}},request:job.request,quality:job.quality,reproducibility:{status:'passed',runs:2,resultHash:firstHash,repeatedHash:secondHash},accounting,result:first,limitations:['历史沪深300成员按BaoStock周度快照；不证明交易所逐事件历史可得性','公司行动资料不完整或遇到未支持的配股时阻止正式回测','单标的历史样本不保证盈利；未平仓和未配对T均保留在报告']};
    await this.stage(job,'report','保存完整报告、交易明细与净值曲线');await this.saveReport(job,report);job.metrics=first.metrics;stopTiming(job,this.clock(),'completed');job.status='completed';job.stage='completed';delete job.error;await this.save(job,job.quality.status==='warning'?'回测完成，量价警告已写入报告；不代表数据已修复或策略盈利':job.acceptance==='passed'?'真实数据流程验收通过（不代表策略盈利）':'合成夹具流程测试完成，不属于真实数据验收');
  }
  async saveReport(job,report){const bytes=canonical(report),id=hash(bytes);await atomic(path.join(this.root,'reports',id+'.json'),bytes);job.reportHash=id;job.reportRun=job.timing.runs.length;await this.save(job);}
  async python(){if(process.env.ASHARE_PYTHON)return process.env.ASHARE_PYTHON;for(const base of ['collector/.venv','.venv']){const venv=path.join(project,base,process.platform==='win32'?'Scripts/python.exe':'bin/python');try{await access(venv);return venv;}catch{}}return process.platform==='win32'?'python':'python3';}
  async sourceStatus(){
    if(this.sourceCache&&Date.now()-this.sourceCache.at<60000)return this.sourceCache.value;
    if(this.sourceProbe)return this.sourceProbe;
    this.sourceProbe=(async()=>{
      const executable=await this.python();let value;
      try{const stdout=await new Promise((resolve,reject)=>execFile(executable,[path.join(project,'collector/sources.py'),'--status'],{cwd:project,env:pythonEnv(),windowsHide:true,timeout:10000,maxBuffer:512*1024,encoding:'utf8'},(error,stdout)=>error?reject(error):resolve(stdout)));
        value={backend:'local',ttlSeconds:60,...JSON.parse(stdout)};
      }catch(e){value={backend:'local',ttlSeconds:60,error:'无法读取Python数据源配置；网页演示仍可运行。请安装Python或设置ASHARE_PYTHON。',code:e.code==='ENOENT'?'PYTHON_MISSING':'SOURCE_STATUS_FAILED',sources:[]};}
      this.sourceCache={at:Date.now(),value};return value;
    })();try{return await this.sourceProbe;}finally{this.sourceProbe=null;}
  }
  async trafficStatus(){
    if(this.trafficCache&&Date.now()-this.trafficCache.at<10000)return this.trafficCache.value;
    if(this.trafficProbe)return this.trafficProbe;
    this.trafficProbe=(async()=>{
      const executable=await this.python();
      try{
        const stdout=await new Promise((resolve,reject)=>execFile(executable,[path.join(project,'collector/baostock_guard.py'),'--inspect'],{cwd:project,env:pythonEnv(),windowsHide:true,timeout:22000,maxBuffer:64*1024,encoding:'utf8'},(error,stdout)=>error?reject(error):resolve(stdout)));
        const value={backend:'local',...JSON.parse(stdout)};this.trafficCache={at:Date.now(),value};return value;
      }catch(e){throw Object.assign(Error(e.code==='ENOENT'?'未找到Python；请安装或设置ASHARE_PYTHON。':'无法读取本机IP与用量；未重置预算，请检查Python与预算文件权限。'),{status:503,code:'TRAFFIC_STATUS_FAILED'});}
    })();try{return await this.trafficProbe;}finally{this.trafficProbe=null;}
  }
  async collectPython(job,collection){
    const executable=await this.python();await rm(path.join(collection,'error.json'),{force:true});
    const child=spawn(executable,[path.join(project,'collector/research_collect.py'),'--request',this.location(job.id,'request.json'),'--root',collection,'--store',path.join(this.root,'market'),'--parent',String(process.pid)],{cwd:project,env:pythonEnv(),windowsHide:true,stdio:['ignore','pipe','pipe']});this.child=child;
    let pending='',stderr='';const abort=()=>{writeFile(path.join(collection,'cancel'),'pause').catch(()=>{});child.kill();};job.controller.signal.addEventListener('abort',abort,{once:true});
    child.stdout.setEncoding('utf8');child.stdout.on('data',chunk=>{pending+=chunk;if(pending.length>1024*1024)pending=pending.slice(-65536);let index;while((index=pending.indexOf('\n'))!==-1){const line=pending.slice(0,index);pending=pending.slice(index+1);try{const p=JSON.parse(line);this.progress(job,p).catch(()=>{});}catch{}}});
    child.stderr.setEncoding('utf8');child.stderr.on('data',chunk=>{stderr=(stderr+chunk).slice(-4000);});
    try{await new Promise((resolve,reject)=>{child.once('error',e=>reject(failure('PYTHON_MISSING','无法启动Python。安装依赖，或设置ASHARE_PYTHON：'+e.code)));child.once('close',code=>code===0?resolve():reject(failure('COLLECTOR_ERROR','采集器中断：'+(stderr.includes('ModuleNotFoundError')?'缺少Python依赖，请安装collector/requirements.txt':'退出码 '+code))));});}
    catch(e){this.check(job);let detail;try{detail=JSON.parse(await readFile(path.join(collection,'error.json'),'utf8'));}catch{}throw detail?failure(detail.code,detail.error,detail.traceback?{collectorTraceback:detail.traceback}:undefined):e;}
    finally{job.controller.signal.removeEventListener('abort',abort);this.child=null;}
  }
  async runEngine(job,snapshot,config){
    if(this.runner)return this.runner(snapshot,config,job.controller.signal);
    const runner=new Worker(path.join(project,'server/research-runner.mjs'),{workerData:{snapshot,config}});this.engineWorker=runner;
    const abort=()=>runner.terminate();job.controller.signal.addEventListener('abort',abort,{once:true});
    try{return await new Promise((resolve,reject)=>{let received=false;runner.once('message',m=>{received=true;m.error?reject(failure('ENGINE_ERROR',m.error)):resolve(m.result);});runner.once('error',reject);runner.once('exit',code=>{if(!received)reject(failure(job.controller.signal.aborted?'PAUSED':'ENGINE_ERROR','回测线程退出：'+code));});});}
    finally{job.controller.signal.removeEventListener('abort',abort);await runner.terminate();this.engineWorker=null;}
  }
  async pause(id){const job=this.jobs.get(id);if(!job)throw failure('NOT_FOUND','任务不存在');if(!['running','queued'].includes(job.status))throw failure('STATE','任务当前无需暂停');
    if(job===this.active){job.controller.abort();await this.running;}else{job.status='paused';await this.save(job,'用户暂停，等待恢复');}return this.view(job);
  }
  async resume(id){const job=this.jobs.get(id);if(!job?.request)throw failure('NOT_FOUND','任务请求损坏或不存在');if(!['paused','blocked','failed'].includes(job.status))throw failure('STATE','仅暂停或受阻任务可以恢复');if(job.request.purpose!=='collect'&&job.engineHash!==this.fingerprint)throw failure('ENGINE_CHANGED','引擎已变更，请创建新任务');job.status='queued';delete job.error;delete job.collectorError;await this.save(job,'从已核验的检查点恢复');this.pump();return this.view(job);}
  async report(job){if(!job?.reportHash)throw failure('NOT_FOUND','报告尚未生成');const body=await readFile(path.join(this.root,'reports',job.reportHash+'.json'));if(hash(body)!==job.reportHash)throw failure('REPORT_HASH','报告文件哈希不一致');return body;}
  async repeat(id){const job=this.jobs.get(id);if(job?.status!=='completed')throw failure('STATE','仅完成的任务可固定快照复现');await this.report(job);if(job.request.purpose!=='collect'&&job.engineHash!==this.fingerprint)throw failure('ENGINE_CHANGED','引擎已变更，无法按原版本复现');return this.create(null,{replay:job});}
  async close(){this.stopping=true;await this.batchWrites.catch(()=>{});if(this.active){this.active.controller?.abort();await this.running;}await this.saves;await rm(this.lock,{recursive:true,force:true});}
  async fetch(request){
    try{const url=new URL(request.url),pathname=url.pathname,base='/api/research/jobs';
      if(pathname==='/api/research/sources'&&request.method==='GET')return jsonResponse(await this.sourceStatus());
      if(request.method==='POST'){const origin=request.headers.get('origin');if(origin&&origin!==url.origin)return jsonResponse({error:'只接受本站任务写入'},403);if(!request.headers.get('content-type')?.startsWith('application/json'))return jsonResponse({error:'需要JSON请求'},415);}
      if(pathname==='/api/research/traffic'&&request.method==='POST')return jsonResponse(await this.trafficStatus());
      if(pathname===base&&request.method==='GET')return jsonResponse({jobs:[...this.jobs.values()].sort((a,b)=>b.createdAt.localeCompare(a.createdAt)).map(j=>this.view(j)),batches:[...this.batches.values()].sort((a,b)=>b.createdAt.localeCompare(a.createdAt)).map(b=>this.batchView(b)),backend:'local',serial:true});
      if(pathname===base&&request.method==='POST')return jsonResponse(await this.create(await request.json()),202);
      if(pathname==='/api/research/batches'&&request.method==='POST')return jsonResponse(await this.createBatch(await request.json()),202);
      const batchMatch=pathname.match(/^\/api\/research\/batches\/([a-f0-9]{24})(?:\/(pause|resume))?$/);if(batchMatch){const b=this.batches.get(batchMatch[1]);if(!b)return jsonResponse({error:'批次不存在'},404);if(!batchMatch[2]&&request.method==='GET')return jsonResponse(this.batchView(b));if(batchMatch[2]&&request.method==='POST')return jsonResponse(await this[batchMatch[2]+'Batch'](b.id),202);return jsonResponse({error:'批次方法不存在'},405);}
      const match=pathname.match(/^\/api\/research\/jobs\/([a-f0-9]{24})(?:\/(pause|resume|repeat|report|timing))?$/);if(!match)return jsonResponse({error:'任务接口不存在'},404);const job=this.jobs.get(match[1]);if(!job)return jsonResponse({error:'任务不存在'},404);
      if(!match[2]&&request.method==='GET')return jsonResponse(this.view(job));
      if(match[2]==='report'&&request.method==='GET')return new Response(await this.report(job),{headers:{'content-type':'application/json; charset=utf-8','content-disposition':'attachment; filename="'+job.id+'-report.json"','cache-control':'no-store','etag':'"'+job.reportHash+'"'}});
      if(match[2]==='timing'&&request.method==='GET'){
        await this.saves;let events=[];try{events=(await readFile(this.location(job.id,'events.jsonl'),'utf8')).trim().split('\n').filter(Boolean).map(JSON.parse);}catch(e){if(e.code!=='ENOENT')throw e;}
        return new Response(JSON.stringify({id:job.id,status:job.status,stage:job.stage,timing:timingView(job,this.clock()),queryTiming:job.queryTiming??{},events:events.length?events:job.events,notes:['activeMs只包含实际执行，包括网络与限流等待；暂停、排队、停机时间不计入','每5秒落盘；异常退出最多缺少最后未落盘片段，标记interruptedTailUnmeasured','legacyUnmeasured表示升级前没有计时，旧耗时无法补测','耗时与日志独立于确定性回测报告哈希']}),{headers:{'content-type':'application/json; charset=utf-8','content-disposition':'attachment; filename="'+job.id+'-timing.json"','cache-control':'no-store'}});
      }
      if(['pause','resume','repeat'].includes(match[2])&&request.method==='POST')return jsonResponse(await this[match[2]](job.id),202);
      return jsonResponse({error:'任务方法不存在'},405);
    }catch(e){return jsonResponse({error:e.message,code:e.code??'TASK_ERROR',...(e.details?.parameter?{parameter:e.details.parameter}:{})},e.status??(e.code==='NOT_FOUND'?404:e.code==='REQUEST'||e.message.includes('参数')?400:409));}
  }
}
